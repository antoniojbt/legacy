#!/bin/bash

bash 00_eQTL_genotype_process.sh \
	P140343-Results_FinalReport_clean_SNPs_autosome_individuals \
	P140343-Results_FinalReport_clean_SNPs_autosome_individuals.matrixQTL \
	P140343-Results_FinalReport_clean_SNPs_autosome_individuals.A-transpose \
	P140343-Results_FinalReport_clean_SNPs_autosome_individuals.A-transpose.matrixQTL.geno

