#!/bin/bash
/Library/Frameworks/R.framework/Resources/bin/Rscript \
/Users/antoniob/Desktop/scripts_to_upload/GAT_backgrounds_2/XGR_downstream_analysis.R \
Diff_exp_BESTD_FDR10.txt \
background_genes_BESTD_expressed.txt