===========
Word counts
===========

This is an test report to check if the template
pipeline has been corretly set up. You should see
a plot below:

.. report:: TemplateReport.WordFrequencies
   :render: histogram-plot
   :transform: histogram
   
   Histogram of word frequencies

.. report:: TemplateReport.WordFrequencies
   :render: table
   :transform: stats
   
   Distribution of word frequencies
