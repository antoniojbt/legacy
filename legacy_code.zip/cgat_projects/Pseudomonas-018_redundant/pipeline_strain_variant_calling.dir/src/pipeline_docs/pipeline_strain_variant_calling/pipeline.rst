.. toctree::
   :maxdepth: 2

   pipeline/Methods.rst
   pipeline/Dummy.rst
  
