========
Analysis
========

.. toctree::
   :maxdepth: 2

   analysis/Conclusions.rst
   analysis/Introduction.rst   
   analysis/Methods.rst
   analysis/Results.rst
   analysis/Discussion.rst
   analysis/History.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


