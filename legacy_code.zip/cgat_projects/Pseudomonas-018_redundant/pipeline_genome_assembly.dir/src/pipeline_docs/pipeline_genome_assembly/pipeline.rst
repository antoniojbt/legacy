.. _genome_assemblypipeline:

=============================
genome_assembly pipeline
=============================

Contents:

.. toctree::
   :maxdepth: 2

   pipeline/Methods.rst
   pipeline/Dummy.rst
 
.. errorlist::
  
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


