==========
Contents
==========

Contents:

.. toctree::
   :maxdepth: 2

   analysis.rst
   pipeline.rst

====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


