======
Status
======

Running the pipeline
====================

The following report lists the completion status of all pipelines.

.. report:: TestingReport.PipelineStatus 
   :render: status                  
   
   Status report of pipeline running. The info field shows the last
   time the pipeline was started.

Pipeline reports
================
