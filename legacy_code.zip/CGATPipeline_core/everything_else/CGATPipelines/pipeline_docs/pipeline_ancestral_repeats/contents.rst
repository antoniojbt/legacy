.. Test documentation master file, created by
   sphinx-quickstart on Mon Mar 23 15:27:57 2009.

==========
 Contents
==========

Contents:

.. toctree::
   :maxdepth: 2

   analysis.rst
   pipeline.rst
   usage.rst

====================
 Indices and tables
====================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


