.. Test documentation master file, created by
   sphinx-quickstart on Mon Mar 23 15:27:57 2009.

.. _template_pipeline:

==================
Template pipeline
==================

Contents:

.. toctree::
   :maxdepth: 2

   pipeline/Methods.rst
 
.. errorlist::
  
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


