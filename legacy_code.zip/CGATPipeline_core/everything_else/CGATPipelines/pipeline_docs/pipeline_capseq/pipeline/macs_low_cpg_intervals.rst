===================================
MACS Intervals with Low CpG Density
===================================

This sections lists binding intervals with GC content < 0.5  and CpG observed / expected < 0.6.

.. report:: macs_interval_lists.IntervalListLowGC
   :render: table
   :groupby: track
   :force:

   Intervals GC content < 0.5  and CpG observed / expected < 0.6

