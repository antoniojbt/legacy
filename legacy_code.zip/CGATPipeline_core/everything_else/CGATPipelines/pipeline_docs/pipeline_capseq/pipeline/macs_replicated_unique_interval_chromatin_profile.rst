==========================
Chromatin Profile
==========================

Density of chromatin marks over tissue-specific CAPseq intervals.

.. report:: macs_replicated_unique_interval_chromatin_profile.chromatinProfileTracker
   :render: gallery-plot
   :glob: replicated_intervals/*.profile.png
   :layout: column-2

   Density of chromatin mark reads over tissue-specific CAPseq intervals






