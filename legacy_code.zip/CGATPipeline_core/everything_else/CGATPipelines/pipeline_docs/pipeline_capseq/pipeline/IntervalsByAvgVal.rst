===================================
MACS Intervals by Average Coverage
===================================

This sections lists binding intervals of interest.

.. report:: macs_interval_lists.IntervalListAvgval
   :render: table
   :groupby: track

   Intervals with largest average coverage in the ChIP sample

