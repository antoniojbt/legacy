==============================
MACS Intervals Overlapping CDS
==============================

.. report:: macs_interval_lists.IntervalListCDS
   :render: table
   :groupby: track
   :force:

   Intervals sorted by CDS overlap percentage.

