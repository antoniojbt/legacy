==================================
MACS Intervals by Maximum Coverage
==================================

This sections lists binding intervals of interest.

.. report:: macs_interval_lists.IntervalListPeakval
   :render: table
   :groupby: track

   Intervals with largest maximum coverage in the ChIP sample

