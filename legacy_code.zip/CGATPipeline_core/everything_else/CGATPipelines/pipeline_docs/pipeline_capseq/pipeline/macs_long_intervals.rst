===================================
MACS Intervals >3kb in Length
===================================

This sections lists CAPseq intervals > 3kb in length which overlap at least 20% of an Ensembl protein-coding gene model.

.. report:: macs_interval_lists.LongIntervals
   :render: table
   :groupby: track
   :force:

   Intervals > 3kb in length

