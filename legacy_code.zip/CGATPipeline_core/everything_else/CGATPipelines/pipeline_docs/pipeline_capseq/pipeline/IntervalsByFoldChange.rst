===============================
MACS Intervals by Fold Change
===============================

This sections lists binding intervals of interest.

.. report:: macs_interval_lists.IntervalListFoldChange
   :render: table
   :groupby: track

   Intervals sorted by fold change.
   The fold change is computed as the number
   of reads in the interval in the ChIP sample
   compared to the input sample.


