=============
Bioprospector
=============

.. report:: BioProspector.BioProspectorMotifs
   :render: table
   :force:

   Motifs found by BioProspector
