===========
CpGCoverage
===========

.. report:: MetaMedipReport.SummaryCpGCoverage
   :render: table
   :force:
   :groupby: track

   Table with CpG coverage for each experiment and track.
