========================
Differential methylation
========================

The following tables show the number of intervals that have been
called differentially methylated.

.. report:: MetaMedipReport.SummaryCalledDMRs
   :render: table                                                   

   Number of regions that have been called differentially methylated
