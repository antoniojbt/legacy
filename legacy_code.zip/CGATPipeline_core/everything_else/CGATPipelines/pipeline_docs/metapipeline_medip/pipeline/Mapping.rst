=======================
Mapping
=======================

.. report:: MetaMedipReport.SummaryMapping
   :render: table  
   :force: 

   Table with mapping summaries
