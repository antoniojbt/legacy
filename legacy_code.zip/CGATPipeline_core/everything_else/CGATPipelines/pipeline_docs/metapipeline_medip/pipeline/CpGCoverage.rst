===========
CpGCoverage
===========

This page summarizes the number of CpG that are covered by reads.

.. report:: MetaMedipReport.SummaryCpGCoverage
   :render: table
   :force:
   :groupby: track

   Table with CpG coverage for each experiment and track.


