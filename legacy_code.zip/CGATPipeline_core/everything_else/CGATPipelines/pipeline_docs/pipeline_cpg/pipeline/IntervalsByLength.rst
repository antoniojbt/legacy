========================
MACS Intervals by Length
========================

This sections lists binding intervals of interest.

.. report:: macs_interval_lists.IntervalListLength
   :render: table
   :groupby: track

   Longest intervals

