===================================
MACS Intervals >10kb in Length
===================================

This sections lists binding intervals > 10kb in Length sorted by fold change,

.. report:: macs_interval_lists.LongIntervals
   :render: table
   :groupby: track
   :force:

   Intervals > 10kb in length

