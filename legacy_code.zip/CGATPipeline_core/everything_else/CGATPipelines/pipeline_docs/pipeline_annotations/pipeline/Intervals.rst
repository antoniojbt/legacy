Bed formatted intervals
=======================

.. report:: AnnotationReport.BedSummaryIntervals
   :render: interleaved-bar-plot
   :logscale: z
   :width: 1000

   Number of intervals in various annotation files

.. report:: AnnotationReport.BedSummaryBases
   :render: interleaved-bar-plot
   :logscale: z
   :width: 1000

   Number of nucleotides covered in various annotation
   files
