Pipeline status
===============

.. report:: Status.AnnotationStatus
   :render: status

   Pipeline status information
