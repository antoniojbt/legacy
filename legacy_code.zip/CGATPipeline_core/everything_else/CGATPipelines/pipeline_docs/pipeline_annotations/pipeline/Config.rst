Pipeline configuration
======================

This page lists the pipeline configuration parameters.

.. report:: Tracker.Config
   :render: table

   Pipeline configuration values
