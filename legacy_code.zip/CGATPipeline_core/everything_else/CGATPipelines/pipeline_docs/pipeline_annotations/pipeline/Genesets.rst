Genesets
========

This section lists the number of genes and transcripts in various
tables in the annotation pipeline.

.. report:: AnnotationReport.InfoTable
   :render: interleaved-bar-plot

   Table with number of unique gene_ids and transcript_ids in
   various tables.

.. report:: AnnotationReport.InfoTable
   :render: table

   Table with number of unique gene_ids and transcript_ids in
   various tables.

